<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class Contactmodel extends Model {

	protected $table = 'kontak';
	public $timestamps = false;
}
